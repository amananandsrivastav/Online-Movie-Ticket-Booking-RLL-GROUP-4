# Online-Movie-Ticket-Booking-RLL-GROUP-4
This is a systematic web application that we have created where user can experience a seam less process of buying his/her favorite movies.
# Background of the project
NMS Cinemas is a group of movie theaters that show different kinds of movies at affordable prices. They started in 2004 in Pune, India. 
Lately, the people who study the business noticed that their sales went down after 2010. 
They figured out that apps like BookMyShow and Paytm were making more money by letting people book tickets online, without needing middlemen. 
Because of this, the team decided to hire someone who can build a website for booking movie tickets. They want the website to be easy for users and look nice. 
They hired you as a developer to make this website. The bosses gave you the things the website needs and how their business works, so you can make different parts of the website fit together.

